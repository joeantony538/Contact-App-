package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextClock;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public TextView signup;
    public TextInputEditText emailSin;
    public TextInputEditText pwdSin;
    public Button Sinb;
    DatabaseHelper myDB;
    ListView user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        emailSin = (TextInputEditText) findViewById(R.id.emailsin);
        pwdSin = (TextInputEditText) findViewById(R.id.pwdsin);
        Sinb = (Button) findViewById(R.id.sinb);

        signup = (TextView) findViewById(R.id.sup);

                signup.setOnClickListener(view -> {
                    Intent intent= new Intent( MainActivity.this,MainActivity2.class);
                    startActivity(intent);
                });
        myDB = new DatabaseHelper(MainActivity.this);



    }


}