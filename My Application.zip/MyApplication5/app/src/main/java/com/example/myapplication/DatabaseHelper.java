package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME = "user_data.db";
    private static final String DATABASE_VERSION ="1";
    private static final String TABLE_NAME ="user_inf";
    private static final String COLUMN_USERNAME ="user_id";
    private static final String COLUMN_PASSWORD ="password";
    private static final String COLUMN_SECRET ="secret";
    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME ,null, Integer.parseInt(DATABASE_VERSION));

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = " CREATE TABLE " + TABLE_NAME + " (" + COLUMN_USERNAME
                 + " TEXT, " + COLUMN_PASSWORD + " TEXT, " +
                COLUMN_SECRET + " TEXT);";
        db.execSQL(query);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

    }
    void adduserdata(String user_name, String pass_word, String sec_ret) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_USERNAME, user_name);
        cv.put(COLUMN_PASSWORD, pass_word);
        cv.put(COLUMN_SECRET, sec_ret);
        long result = db.insert(TABLE_NAME, null, cv);
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(context, "Successful", Toast.LENGTH_SHORT).show();
        }
    }
        Cursor readAllData() {

            String query = "SELECT user_name FROM " + TABLE_NAME;
            SQLiteDatabase db = this.getReadableDatabase();

            Cursor cursor = null;
            if(db != null){
                cursor = db.rawQuery(query,null);
            }
            return cursor;
        }

}
