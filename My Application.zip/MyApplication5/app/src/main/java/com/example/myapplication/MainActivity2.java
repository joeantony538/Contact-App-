package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;

import java.sql.Connection;

public class MainActivity2 extends AppCompatActivity {

    public TextView signin;
    public TextInputEditText esup;
    public TextInputEditText pwdSup;
    public TextInputEditText secretSup;
    public Button supB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        esup = (TextInputEditText) findViewById(R.id.emailsup);
        pwdSup =(TextInputEditText) findViewById(R.id.pwdsup);
        secretSup =(TextInputEditText) findViewById(R.id.secretsup);
        supB = (Button) findViewById(R.id.supb);
        signin = (TextView) findViewById(R.id.sin);

                signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2. this,MainActivity.class);
                startActivity(intent);
            }
        });

        supB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHelper myDB = new DatabaseHelper(MainActivity2.this);
                myDB.adduserdata(esup.getText().toString().trim(),
                        pwdSup.getText().toString().trim(),
                        secretSup.getText().toString().trim());
            }



        });












    }
}